# GuardAI Local Demo Kit

This folder contains safe local pages for testing GuardAI without visiting real
phishing websites.

## How To Use

1. Load the extension from `guardai/extension` in `chrome://extensions`.
2. Reload the extension after every code change.
3. Open these files in Chrome:
   - `safe-login.html`
   - `suspicious-payment.html`
4. Click the GuardAI extension icon and check the popup score.
5. Try submitting the password form on the suspicious page. GuardAI should stop
   the submit and show a warning banner.

The popup includes an `API` selector:

- `Local` sends backend checks to `http://localhost:8000/v1/analyze`
- `Staging` sends backend checks to `https://api-staging.guardai.io/v1/analyze`
- `Production` is reserved for `https://api.guardai.io/v1/analyze`

Chrome may require file access for extensions:

1. Open `chrome://extensions`.
2. Open GuardAI details.
3. Enable `Allow access to file URLs`.

## Expected Results

| Page | Expected result |
| ---- | --------------- |
| `safe-login.html` | Low score, usual URL, no dangerous warning |
| `suspicious-payment.html` | Higher score after page signals, warning on password submit |
| `http://paypa1.com/login` | Dangerous URL from known phishing heuristic |
| `https://paypal-login-secure.xyz/verify?redirect=%2Faccount` | Dangerous URL from multiple phishing signals |

Do not enter real passwords, card numbers, or personal information into demo
pages. These files are local test fixtures only.
