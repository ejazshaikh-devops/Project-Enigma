"""
GuardAI – API Routes

/v1/analyze  →  The core endpoint. Extension sends a URL, we return a risk score.
/v1/health   →  Quick liveness check (also at root /health).

Every route is rate-limited. Input is validated by Pydantic before
any of our code runs. Errors are caught and returned cleanly — never
exposing internal stack traces to callers.
"""

from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse

from app.api.schemas import AnalyzeRequest, AnalyzeResponse
from app.services.analyzer import analyze
from app.core.limiter import limiter
from app.core.config import settings

router = APIRouter()


@router.post("/analyze", response_model=AnalyzeResponse)
@limiter.limit(settings.RATE_LIMIT)
async def analyze_url(request: Request, body: AnalyzeRequest):
    """
    Main detection endpoint.

    The Chrome extension POSTs here on every page navigation.
    We run backend analysis and return a combined risk score.

    Target response time: < 150ms for cached/simple cases.
    """
    try:
        result = await analyze(
            url=body.url,
            local_score=body.local_score,
            local_flags=body.local_flags,
        )
        return AnalyzeResponse.from_score(result["risk_score"], result["flags"])

    except ValueError as e:
        # Input problem — tell the caller what's wrong
        raise HTTPException(status_code=422, detail=str(e))

    except Exception:
        # Never leak internal errors to callers
        # In production, this goes to your error monitoring (Sentry etc.)
        raise HTTPException(status_code=500, detail="Analysis failed")


@router.get("/health")
async def health():
    return {"status": "ok", "version": "0.1.0"}
