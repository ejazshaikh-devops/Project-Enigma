# GuardAI – AI-Powered Phishing & Scam Detector

> Real-time browser security powered by AI. Protects users from phishing, scam websites, fake login pages, and fraudulent payment pages.

---

## 🏗️ Project Status

GuardAI is a working proof of concept today. It is not production-ready or
investor-ready yet, but it has enough real code to grow from a prototype into a
measured beta product.

| Phase | Status | Description |
|-------|--------|-------------|
| Phase 1 | ✅ Baseline hardening | Chrome Extension + Backend skeleton |
| Phase 2 | ⏳ Next | Reliable local beta + secure API communication |
| Phase 3 | 🔜 Planned | Feature extraction engine |
| Phase 4 | 🔜 Planned | ML phishing model |
| Phase 5 | 🔜 Planned | Warning system |
| Phase 6 | 🔜 Planned | AWS deployment |
| Phase 7 | 🔜 Planned | Advanced AI detection |

---

## 📁 Project Structure

```
guardai/
├── extension/          # Chrome Extension (Manifest V3)
│   ├── manifest.json   # Extension configuration
│   ├── background/     # Service worker (the brain)
│   ├── content/        # Scripts that run on web pages
│   ├── popup/          # The UI when clicking the extension icon
│   └── utils/          # URL analyzer, API client
│
├── backend/            # Python FastAPI server
│   ├── main.py         # Entry point
│   ├── app/
│   │   ├── api/        # Routes and request/response schemas
│   │   ├── core/       # Config, security
│   │   └── services/   # Business logic (analysis engine)
│   ├── requirements.txt
│   └── Dockerfile
│
├── ai-engine/          # ML models and training
├── infra/              # Docker Compose, Nginx, CI/CD
├── monitoring/         # Prometheus, Grafana
└── docs/               # Architecture docs, threat model
```

Investor-readiness path: [`docs/investor_readiness_roadmap.md`](docs/investor_readiness_roadmap.md)
Local demo kit: [`demo/README.md`](demo/README.md)

---

## 🚀 Quick Start

### Load the Chrome Extension (for testing)

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer Mode** (top right toggle)
3. Click **Load Unpacked**
4. Select the `extension/` folder
5. The GuardAI shield icon will appear in your toolbar

### Run the Backend Locally

```bash
cd infra/
docker-compose up
```

The API will be available at `http://localhost:8000`

Check it's running: `http://localhost:8000/health`

### Run Extension Scoring Smoke Test

```bash
node scripts/smoke_extension_scoring.js
```

This verifies the popup scoring logic against safe, suspicious, and
phishing-style URLs without opening Chrome.

### Run Backend Smoke Checks

```bash
./scripts/run_backend_checks.sh
```

Backend testing notes: [`backend/TESTING.md`](backend/TESTING.md)

### AWS Staging Deployment

Deployment guide: [`infra/aws/staging_deployment.md`](infra/aws/staging_deployment.md)
Kubernetes manifests: [`infra/k8s/README.md`](infra/k8s/README.md)

---

## 🔒 Security Design Principles

1. **Zero sensitive data collection** — We only analyze URLs, never page content or form values
2. **Minimal permissions** — The extension requests only what it needs
3. **HTTPS only** — All API communication is encrypted
4. **Rate limiting** — Prevents abuse of our detection API
5. **Input validation** — All inputs sanitized before processing
6. **CSP hardened** — Extension pages cannot load external scripts
7. **Non-root containers** — Docker runs as a restricted user

---

## 📊 Threat Model

| Threat | Mitigation |
|--------|-----------|
| Phishing URL not detected | Multi-layer: local heuristics + backend AI + known-domain list |
| Extension leaks user data | Content scripts never transmit form values |
| API key exposure | Keys stored in chrome.storage, never in source code |
| SSRF attack via URL input | URL validation blocks internal network addresses |
| API abuse/DDoS | Rate limiting at extension and backend levels |
| Malicious extension update | Chrome Web Store review + code signing |

---

## 👥 Team

Built as a cybersecurity startup. CTO-led architecture with security-first engineering principles.

---

*This project is built phase by phase — like a real startup.*
