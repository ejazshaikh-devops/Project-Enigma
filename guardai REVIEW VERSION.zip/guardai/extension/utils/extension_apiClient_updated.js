/**
 * GuardAI – API Client (Phase 2 — Local Backend)
 *
 * CHANGE FROM PHASE 1:
 * Now points to your real local backend running on localhost:8000.
 * When you later deploy to production, change API_BASE_URL to your
 * real server domain (e.g. https://api.guardai.io).
 *
 * SECURITY:
 * - No API keys hardcoded here
 * - 8-second timeout so a slow server never freezes browsing
 * - Response shape is validated before trusting any values
 * - Fails silently — if backend is down, local heuristics still work
 */

// ── Switch this URL when you deploy to production ─────────────────────────────
const API_BASE_URL      = 'http://localhost:8000';
const ANALYZE_ENDPOINT  = `${API_BASE_URL}/v1/analyze`;
const REQUEST_TIMEOUT_MS = 8000;

/**
 * Sends a URL to the backend for AI-assisted analysis.
 *
 * @param {string} url         – The page URL
 * @param {object} localResult – { score, flags } from urlAnalyzer.js
 * @returns {Promise<object|null>}
 */
export async function sendToAPI(url, localResult) {
  try {
    const controller = new AbortController();
    const timeout    = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    const response = await fetch(ANALYZE_ENDPOINT, {
      method:  'POST',
      headers: {
        'Content-Type':       'application/json',
        'X-Extension-Version': chrome.runtime.getManifest().version,
      },
      body: JSON.stringify({
        url:         url,
        local_score: localResult.score,
        local_flags: localResult.flags,
        timestamp:   Date.now(),
      }),
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!response.ok) {
      console.warn(`[GuardAI] Backend returned HTTP ${response.status}`);
      return null;
    }

    const data = await response.json();

    if (!isValidResponse(data)) {
      console.warn('[GuardAI] Unexpected response shape from backend:', data);
      return null;
    }

    return data;

  } catch (err) {
    if (err.name === 'AbortError') {
      console.warn('[GuardAI] Backend request timed out');
    } else {
      console.warn('[GuardAI] Backend unreachable — using local score only');
    }
    return null;
  }
}

function isValidResponse(data) {
  return (
    data !== null &&
    typeof data === 'object' &&
    typeof data.risk_score === 'number' &&
    data.risk_score >= 0 &&
    data.risk_score <= 1 &&
    typeof data.verdict === 'string' &&
    Array.isArray(data.flags)
  );
}
