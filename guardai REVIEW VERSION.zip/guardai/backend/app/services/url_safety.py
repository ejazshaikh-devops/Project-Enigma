"""
URL safety validation shared by API schemas and lightweight smoke tests.

Keeping these checks outside Pydantic makes the security-critical SSRF logic
easy to test even before the full backend dependency environment is installed.
"""

import ipaddress
from urllib.parse import urlparse


def validate_public_http_url(value: str) -> str:
    url = value.strip()

    if not url.startswith(("http://", "https://")):
        raise ValueError("URL must start with http:// or https://")

    if len(url) > 2048:
        raise ValueError("URL too long (max 2048 characters)")

    parsed = urlparse(url)
    hostname = (parsed.hostname or "").lower()

    if not hostname:
        raise ValueError("URL must include a hostname")

    if hostname in {"localhost", "metadata.google.internal"}:
        raise ValueError("URL references an internal address")

    try:
        ip = ipaddress.ip_address(hostname)
    except ValueError:
        return url

    if (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_reserved
        or ip.is_multicast
        or ip.is_unspecified
    ):
        raise ValueError("URL references an internal address")

    return url

