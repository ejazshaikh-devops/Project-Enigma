/**
 * GuardAI – Content Script: detector.js
 * NO IMPORTS — content scripts cannot use ES modules
 */

(function () {
  'use strict';

  if (window.__guardai_detector_loaded) return;
  window.__guardai_detector_loaded = true;

  function analyzePageContent() {
    const signals = {
      hasPasswordField:   false,
      hasEmailField:      false,
      hasPaymentFields:   false,
      suspiciousKeywordCount: 0,
      formCount:          0,
      externalFormAction: false,
    };

    const inputs = document.querySelectorAll('input');
    inputs.forEach(function(input) {
      var type = (input.type || '').toLowerCase();
      var name = (input.name || input.id || '').toLowerCase();
      if (type === 'password') signals.hasPasswordField = true;
      if (type === 'email' || name.includes('email') || name.includes('user')) {
        signals.hasEmailField = true;
      }
      if (name.includes('card') || name.includes('cvv') ||
          name.includes('expir') || name.includes('billing')) {
        signals.hasPaymentFields = true;
      }
    });

    var forms = document.querySelectorAll('form');
    signals.formCount = forms.length;
    var currentDomain = window.location.hostname;
    forms.forEach(function(form) {
      var action = form.getAttribute('action') || '';
      if (action.startsWith('http') && !action.includes(currentDomain)) {
        signals.externalFormAction = true;
      }
    });

    var bodyText = (document.body && document.body.innerText || '').toLowerCase();
    var phrases = [
      'verify your account', 'account suspended', 'urgent action required',
      'confirm your identity', 'your account will be closed',
      'update your payment', 'bank verification required',
      'login to continue', 'verify your email'
    ];
    phrases.forEach(function(phrase) {
      if (bodyText.includes(phrase)) signals.suspiciousKeywordCount += 1;
    });

    if (signals.hasPasswordField || signals.hasPaymentFields ||
        signals.suspiciousKeywordCount > 0) {
      chrome.runtime.sendMessage({
        type:    'PAGE_ANALYSIS',
        url:     window.location.href,
        signals: signals,
      });
    }
  }

  if (document.readyState === 'complete') {
    analyzePageContent();
  } else {
    window.addEventListener('load', analyzePageContent);
  }

})();
