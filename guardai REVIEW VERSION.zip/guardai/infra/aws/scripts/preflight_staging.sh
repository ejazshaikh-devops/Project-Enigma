#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib.sh"

load_env_file "${1:-}"
require_env \
  AWS_REGION \
  AWS_ACCOUNT_ID \
  ECR_REPOSITORY \
  EKS_CLUSTER_NAME \
  K8S_NAMESPACE \
  API_HOSTNAME \
  ACM_CERTIFICATE_ARN \
  CHROME_EXTENSION_ID \
  API_DATABASE_URL \
  API_SECRET_KEY

require_command aws
require_command docker
require_command kubectl
require_command curl
verify_aws_account

echo "== AWS identity =="
aws sts get-caller-identity --query 'Arn' --output text

echo
echo "== ECR repository =="
if aws ecr describe-repositories \
  --region "$AWS_REGION" \
  --repository-names "$ECR_REPOSITORY" >/dev/null 2>&1; then
  echo "ECR repository exists: $ECR_REPOSITORY"
else
  echo "ECR repository missing. Create it with:"
  echo "  aws ecr create-repository --region $AWS_REGION --repository-name $ECR_REPOSITORY"
fi

echo
echo "== EKS cluster =="
aws eks describe-cluster \
  --region "$AWS_REGION" \
  --name "$EKS_CLUSTER_NAME" \
  --query 'cluster.status' \
  --output text

echo
echo "== Kubernetes access =="
aws eks update-kubeconfig --region "$AWS_REGION" --name "$EKS_CLUSTER_NAME" >/dev/null
kubectl version --client=true
kubectl auth can-i get pods -n "$K8S_NAMESPACE" || true
kubectl auth can-i apply -n "$K8S_NAMESPACE" || true

echo
echo "== Render staging manifests with env values =="
"$SCRIPT_DIR/render_staging_manifests.sh" "${1:-}" >/tmp/guardai-staging-rendered.yaml
if grep -q 'REPLACE_WITH' /tmp/guardai-staging-rendered.yaml; then
  die "Rendered manifest still contains placeholders."
fi
echo "Rendered manifest: /tmp/guardai-staging-rendered.yaml"

echo
echo "Preflight complete."
