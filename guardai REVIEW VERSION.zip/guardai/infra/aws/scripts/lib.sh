#!/usr/bin/env bash
set -euo pipefail

die() {
  echo "ERROR: $*" >&2
  exit 1
}

require_command() {
  command -v "$1" >/dev/null 2>&1 || die "Missing required command: $1"
}

load_env_file() {
  local env_file="${1:-}"
  [[ -n "$env_file" ]] || die "Usage: $0 path/to/staging.env"
  [[ -f "$env_file" ]] || die "Env file not found: $env_file"

  set -a
  # shellcheck disable=SC1090
  source "$env_file"
  set +a
}

require_env() {
  local missing=0
  for name in "$@"; do
    if [[ -z "${!name:-}" ]]; then
      echo "Missing env value: $name" >&2
      missing=1
    fi
  done
  [[ "$missing" -eq 0 ]] || exit 1
}

repo_root() {
  cd "$(dirname "${BASH_SOURCE[0]}")/../../../.." && pwd
}

image_tag_or_git_sha() {
  if [[ -n "${IMAGE_TAG:-}" ]]; then
    echo "$IMAGE_TAG"
    return
  fi

  if git rev-parse --short HEAD >/dev/null 2>&1; then
    git rev-parse --short HEAD
    return
  fi

  date +%Y%m%d%H%M%S
}

ecr_registry() {
  echo "${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
}

ecr_image_uri() {
  echo "$(ecr_registry)/${ECR_REPOSITORY}"
}

verify_aws_account() {
  require_command aws

  local actual_account
  actual_account="$(aws sts get-caller-identity --query Account --output text)"

  if [[ "$actual_account" != "$AWS_ACCOUNT_ID" ]]; then
    die "AWS_ACCOUNT_ID is '$AWS_ACCOUNT_ID' but your active AWS account is '$actual_account'. Update staging.env or switch AWS_PROFILE."
  fi
}
