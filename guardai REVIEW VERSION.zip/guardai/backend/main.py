"""
GuardAI Backend – main.py
Entry point for the FastAPI server.

HOW TO RUN LOCALLY (without Docker):
  pip install -r requirements.txt
  uvicorn main:app --reload --port 8000

HOW TO RUN WITH DOCKER:
  docker-compose up --build

Then test it's working:
  Open browser → http://localhost:8000/health
  You should see: {"status":"ok","version":"0.1.0"}
"""

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn
import time

from app.api.routes import router
from app.core.config import settings
from app.core.limiter import limiter
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware

# ── Create app ────────────────────────────────────────────────────────────────

app = FastAPI(
    title="GuardAI API",
    version="0.1.0",
    # Disable public docs in production — change to /docs for local dev only
    docs_url="/docs" if settings.DEBUG else None,
    redoc_url=None,
)

# ── Rate limiting middleware ───────────────────────────────────────────────────

app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.add_middleware(SlowAPIMiddleware)

# ── CORS — only allow requests from our Chrome extension ──────────────────────
# In production, replace with your real extension ID from Chrome Web Store

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["POST", "GET"],
    allow_headers=["Content-Type", "X-Extension-Version"],
)

# ── Security headers on every response ───────────────────────────────────────

@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    response.headers["X-Content-Type-Options"]  = "nosniff"
    response.headers["X-Frame-Options"]         = "DENY"
    response.headers["X-XSS-Protection"]        = "1; mode=block"
    response.headers["Referrer-Policy"]         = "no-referrer"
    response.headers["Cache-Control"]           = "no-store"
    response.headers["X-Response-Time"]         = f"{(time.time()-start)*1000:.1f}ms"
    return response

# ── Routes ────────────────────────────────────────────────────────────────────

app.include_router(router, prefix="/v1")

# ── Health check ──────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    """Used by Docker, load balancers, and uptime monitors."""
    return {"status": "ok", "version": settings.VERSION}


@app.get("/ready")
async def ready():
    """Used by Kubernetes readiness probes."""
    return {"status": "ready", "version": settings.VERSION}

# ── Local dev entry ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
