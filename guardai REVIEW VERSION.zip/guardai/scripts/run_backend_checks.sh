#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
BACKEND="$ROOT/backend"

echo "== Python syntax checks =="
python3 -m py_compile \
  "$BACKEND/app/services/analyzer.py" \
  "$BACKEND/app/services/url_safety.py" \
  "$BACKEND/app/api/schemas.py" \
  "$BACKEND/tests/test_analyzer.py"

echo
echo "== Backend analyzer smoke test =="
python3 "$ROOT/scripts/smoke_backend_analyzer.py"

echo
echo "== Pytest suite =="
if python3 -m pytest --version >/dev/null 2>&1; then
  (cd "$BACKEND" && python3 -m pytest tests)
else
  echo "SKIP pytest is not installed."
  echo "Install minimal test dependencies with:"
  echo "  cd guardai/backend"
  echo "  python3.12 -m venv .venv"
  echo "  . .venv/bin/activate"
  echo "  python -m pip install -r requirements-test.txt"
  echo "  pytest tests"
fi
