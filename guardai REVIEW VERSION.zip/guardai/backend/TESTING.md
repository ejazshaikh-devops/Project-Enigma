# Backend Testing

GuardAI has two backend verification levels.

## Quick Checks

Run from the repository root:

```bash
./guardai/scripts/run_backend_checks.sh
```

This works without installing backend packages. It verifies:

- Python syntax for key backend files
- Analyzer scoring behavior
- Internal-network URL blocking

## Full Pytest Suite

Use Python 3.12 to match the backend Docker image.

```bash
cd guardai/backend
python3.12 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-test.txt
pytest tests
```

If Docker is running, the full application image can also run tests after it is
built:

```bash
cd guardai/backend
docker compose run --rm api pytest tests
```

