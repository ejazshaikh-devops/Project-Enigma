# AWS Staging Scripts

These scripts deploy the GuardAI backend API to AWS EKS from your local machine.

## First Run

```bash
cp guardai/infra/aws/env/staging.env.example guardai/infra/aws/env/staging.env
```

Edit `guardai/infra/aws/env/staging.env`, then run:

```bash
./guardai/infra/aws/scripts/preflight_staging.sh guardai/infra/aws/env/staging.env
./guardai/infra/aws/scripts/deploy_staging.sh guardai/infra/aws/env/staging.env
./guardai/infra/aws/scripts/smoke_staging_api.sh guardai/infra/aws/env/staging.env
```

## Scripts

- `preflight_staging.sh` checks AWS identity, ECR, EKS, kubectl access, and manifest rendering.
- `build_push_api_image.sh` builds the backend Docker image and pushes it to ECR.
- `render_staging_manifests.sh` renders Kubernetes YAML using your staging env values.
- `deploy_staging.sh` builds, pushes, creates secrets, applies manifests, and waits for rollout.
- `smoke_staging_api.sh` checks `/health`, `/ready`, and `/v1/analyze` over HTTPS.

