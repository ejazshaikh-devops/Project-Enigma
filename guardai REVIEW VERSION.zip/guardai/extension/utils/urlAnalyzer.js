/**
 * GuardAI – URL Analyzer (Local Heuristics)
 *
 * WHY THIS FILE EXISTS:
 * Before we hit the backend API (which takes network time), we run fast
 * local checks on the URL itself. This catches obvious phishing attempts
 * instantly — no internet required.
 *
 * These checks run in milliseconds because they're pure JavaScript logic.
 * Think of it as the first line of defense.
 *
 * SECURITY NOTE:
 * These heuristics are intentionally conservative. It's better to warn
 * about something safe than to miss something dangerous.
 */

// ─── Suspicious keywords commonly found in phishing URLs ─────────────────────

const PHISHING_KEYWORDS = [
  'login', 'signin', 'verify', 'secure', 'account', 'update',
  'banking', 'confirm', 'password', 'credential', 'paypal',
  'apple', 'amazon', 'netflix', 'google', 'microsoft', 'facebook',
  'support', 'suspended', 'urgent', 'alert'
];

// ─── High-risk TLDs often used in phishing (not definitive, just a signal) ────

const SUSPICIOUS_TLDS = [
  '.tk', '.ml', '.ga', '.cf', '.gq', '.xyz', '.top',
  '.click', '.loan', '.work', '.date', '.faith', '.racing'
];

// ─── Legitimate TLDs that are still commonly spoofed ─────────────────────────

const TRUSTED_BRANDS = [
  'paypal', 'apple', 'microsoft', 'amazon', 'netflix',
  'google', 'facebook', 'instagram', 'twitter', 'linkedin',
  'bankofamerica', 'chase', 'wellsfargo', 'hsbc', 'barclays'
];

/**
 * Main function: analyzes a URL and returns a risk score (0.0 – 1.0)
 * and a list of flags explaining why.
 *
 * @param {string} rawUrl - The full URL to analyze
 * @returns {{ score: number, flags: string[] }}
 */
export function analyzeURL(rawUrl) {
  const flags = [];
  let score   = 0.03;

  let parsed;
  try {
    parsed = new URL(rawUrl);
  } catch {
    // Malformed URL is itself suspicious
    return { score: 0.9, flags: ['malformed_url'] };
  }

  const hostname = parsed.hostname.toLowerCase();
  const fullUrl  = rawUrl.toLowerCase();
  const path     = parsed.pathname.toLowerCase();

  // ── 1. HTTP (not HTTPS) ────────────────────────────────────────────────────
  if (parsed.protocol === 'http:') {
    score += 0.15;
    flags.push('no_https');
  }

  // ── 2. IP address as hostname (e.g. http://192.168.1.1/login) ─────────────
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(hostname)) {
    score += 0.35;
    flags.push('ip_address_host');
  }

  // ── 3. Excessive subdomains (e.g. secure.login.paypal.update.xyz.com) ──────
  const subdomainCount = hostname.split('.').length - 2;
  if (subdomainCount >= 3) {
    score += 0.2;
    flags.push('excessive_subdomains');
  }

  // ── 4. Suspicious TLD ─────────────────────────────────────────────────────
  const hasSuspiciousTLD = SUSPICIOUS_TLDS.some(tld => hostname.endsWith(tld));
  if (hasSuspiciousTLD) {
    score += 0.25;
    flags.push('suspicious_tld');
  }

  // ── 5. Hyphen abuse (e.g. paypal-login-secure-verify.com) ─────────────────
  const hyphenCount = (hostname.match(/-/g) ?? []).length;
  if (hyphenCount >= 3) {
    score += 0.15;
    flags.push('excessive_hyphens');
  }

  // ── 6. Brand name in subdomain (spoofing) ─────────────────────────────────
  // Checks if a trusted brand name appears in a subdomain but is NOT the real domain
  // e.g. paypal.fake-login.com → "paypal" is in subdomain, real domain is fake-login.com
  const domainParts  = hostname.split('.');
  const registerable = domainParts.slice(-2).join('.'); // e.g. "fake-login.com"
  const subdomains   = domainParts.slice(0, -2).join('.'); // e.g. "paypal"

  for (const brand of TRUSTED_BRANDS) {
    if (subdomains.includes(brand) && !registerable.startsWith(brand)) {
      score += 0.45;
      flags.push(`brand_spoofed_in_subdomain:${brand}`);
      break;
    }
    if ((registerable.startsWith(`${brand}-`) || registerable.includes(`-${brand}`)) && registerable !== `${brand}.com`) {
      score += 0.35;
      flags.push(`brand_lookalike_domain:${brand}`);
      break;
    }
  }

  // ── 7. Phishing keywords in URL ───────────────────────────────────────────
  let keywordHits = 0;
  for (const kw of PHISHING_KEYWORDS) {
    if (fullUrl.includes(kw)) keywordHits++;
  }
  if (keywordHits >= 3) {
    score += 0.2;
    flags.push(`phishing_keywords:${keywordHits}`);
  }

  // ── 8. Very long URLs (often used to hide the real domain) ────────────────
  if (rawUrl.length > 200) {
    score += 0.1;
    flags.push('long_url');
  }

  // ── 9. URL path contains login/verify patterns ────────────────────────────
  if (/\/(login|signin|verify|secure|account\/update)/.test(path)) {
    score += 0.05; // Minor signal — legitimate sites also have login pages
    flags.push('login_path');
  }

  // ── 10. Unicode homograph attack detection ────────────────────────────────
  // Detects non-ASCII characters used to impersonate Latin letters
  // e.g. payρal.com (ρ = Greek rho)
  if (/[^\x00-\x7F]/.test(hostname)) {
    score += 0.4;
    flags.push('unicode_homograph');
  }

  // ── 11. URL tricks often used to hide the destination ─────────────────────
  if (fullUrl.indexOf('@') > fullUrl.indexOf('//') + 2) {
    score += 0.25;
    flags.push('at_symbol_in_url');
  }

  if (/%2f|%5c|redirect=|returnurl=|next=|url=/i.test(fullUrl)) {
    score += 0.12;
    flags.push('encoded_redirect');
  }

  if (parsed.search && parsed.search.split('&').length >= 6) {
    score += 0.08;
    flags.push('many_query_params');
  }

  // ── Cap score at 1.0 ──────────────────────────────────────────────────────
  score = Math.min(score, 1.0);

  return { score: parseFloat(score.toFixed(3)), flags };
}
