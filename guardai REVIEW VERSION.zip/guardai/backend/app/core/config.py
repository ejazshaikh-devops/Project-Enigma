"""
GuardAI – Core Configuration

RULE: No secrets in code. Ever.
All sensitive values come from environment variables or a .env file.

For local dev: create a file called .env in the backend/ folder.
For production: use AWS Secrets Manager or your hosting platform's env vars.
"""

from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):

    # ── App ──────────────────────────────────────────────────────────────────
    APP_NAME: str  = "GuardAI API"
    VERSION:  str  = "0.1.0"
    DEBUG:    bool = False           # Set to True in .env for local dev only

    # ── Database ─────────────────────────────────────────────────────────────
    # Local dev default — override in .env for your own credentials
    DATABASE_URL: str = "postgresql://guardai:guardai_dev@localhost:5432/guardai"

    # ── CORS — who can call our API ───────────────────────────────────────────
    # During local dev we allow localhost so you can test from a browser tab.
    # In production, replace with your real Chrome Extension ID:
    #   chrome-extension://abcdefghijklmnopqrstuvwxyz123456
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8080",
        "http://127.0.0.1:3000",
        # Add your extension ID here when you have it:
        # "chrome-extension://YOUR_EXTENSION_ID_HERE",
    ]

    # ── Security ──────────────────────────────────────────────────────────────
    # Used for JWT tokens in Phase 2+. Change this to a long random string.
    SECRET_KEY: str = "CHANGE-THIS-TO-A-LONG-RANDOM-STRING-IN-PRODUCTION"

    # ── Rate limiting ─────────────────────────────────────────────────────────
    RATE_LIMIT: str = "60/minute"   # Max requests per IP per minute

    class Config:
        env_file = ".env"           # Loads from backend/.env if it exists
        case_sensitive = True


# Single instance used everywhere in the app
settings = Settings()
