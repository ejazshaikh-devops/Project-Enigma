"""
GuardAI – API Schemas

Pydantic models define exactly what the extension can send us
and exactly what we send back. Any request that doesn't match
these shapes is automatically rejected with a 422 error — no
custom validation code needed.

SECURITY: This is our first line of defense against bad input.
"""

from pydantic import BaseModel, validator
from typing import List, Optional
import time

from app.services.url_safety import validate_public_http_url


# ── What the Chrome extension sends us ───────────────────────────────────────

class AnalyzeRequest(BaseModel):
    url:         str            # The URL to analyze
    local_score: float          # Heuristic score already computed in the extension
    local_flags: List[str]      # Flags already found by the extension
    timestamp:   Optional[int] = None  # Unix ms timestamp from the extension (optional)

    @validator("url")
    def validate_url(cls, v):
        return validate_public_http_url(v)

    @validator("local_score")
    def validate_score(cls, v):
        if not 0.0 <= v <= 1.0:
            raise ValueError("Score must be between 0.0 and 1.0")
        return round(v, 4)

    @validator("local_flags")
    def validate_flags(cls, v):
        if len(v) > 25:
            raise ValueError("Too many flags")
        # Each flag must be a safe alphanumeric string — no injection possible
        cleaned = []
        for flag in v:
            if len(flag) > 120:
                continue  # Skip suspiciously long flags silently
            if not flag.replace("_", "").replace("-", "").replace(":", "").isalnum():
                continue
            cleaned.append(flag)
        return cleaned


# ── What we send back to the extension ───────────────────────────────────────

class AnalyzeResponse(BaseModel):
    risk_score:  float       # 0.0 (safe) → 1.0 (dangerous)
    verdict:     str         # "safe" | "suspicious" | "dangerous"
    flags:       List[str]   # All signals detected (local + backend)
    analyzed_at: int         # Unix timestamp so extension can track freshness

    @staticmethod
    def from_score(score: float, flags: List[str]) -> "AnalyzeResponse":
        """Helper: build a response from a score."""
        if score >= 0.85:
            verdict = "dangerous"
        elif score >= 0.5:
            verdict = "suspicious"
        else:
            verdict = "safe"

        return AnalyzeResponse(
            risk_score=round(score, 4),
            verdict=verdict,
            flags=list(dict.fromkeys(flags)),  # deduplicate while preserving priority
            analyzed_at=int(time.time()),
        )
