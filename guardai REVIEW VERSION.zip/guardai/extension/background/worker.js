/**
 * GuardAI – Background Service Worker
 * Single file, zero imports — fixes Status code 3 error
 */

const RISK_THRESHOLD_WARN  = 0.5;
const RISK_THRESHOLD_BLOCK = 0.85;
const URL_CACHE_TTL_MS     = 5 * 60 * 1000;
const MAX_REQUESTS_PER_MIN = 30;
const REQUEST_TIMEOUT_MS   = 8000;
const DEFAULT_API_ENV      = 'local';
const API_ENVIRONMENTS     = {
  local: {
    label: 'Local',
    endpoint: 'http://localhost:8000/v1/analyze',
  },
  staging: {
    label: 'Staging',
    endpoint: 'https://api-staging.guardai.io/v1/analyze',
  },
  production: {
    label: 'Production',
    endpoint: 'https://api.guardai.io/v1/analyze',
  },
};

const urlCache = new Map();
let requestCount = 0;
let windowStart  = Date.now();

const SUSPICIOUS_TLDS = ['.tk','.ml','.ga','.cf','.gq','.xyz','.top','.click','.loan','.work','.date','.faith','.racing'];
const TRUSTED_BRANDS  = ['paypal','apple','microsoft','amazon','netflix','google','facebook','instagram','twitter','linkedin','bankofamerica','chase','wellsfargo','hsbc','barclays','coinbase','binance','paytm','hdfc','icici','sbi','axis'];
const PHISHING_KW     = ['login','signin','verify','secure','account','update','banking','confirm','password','credential','support','suspended','urgent'];
const KNOWN_PHISHING  = new Set(['paypa1.com','app1e-id.com','g00gle.com','netfl1x-login.com','secure-amazon-verify.xyz']);

// ── URL analysis ──────────────────────────────────────────────────────────────

function analyzeURL(rawUrl) {
  const flags = [];
  let score = 0.03;
  let parsed;
  try { parsed = new URL(rawUrl); }
  catch { return { score: 0.9, flags: ['malformed_url'] }; }

  const hostname = parsed.hostname.toLowerCase();
  const fullUrl  = rawUrl.toLowerCase();
  const path = parsed.pathname.toLowerCase();

  if (parsed.protocol === 'http:')                              { score += 0.15; flags.push('no_https'); }
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(hostname))               { score += 0.35; flags.push('ip_address_host'); }
  if (KNOWN_PHISHING.has(hostname.split('.').slice(-2).join('.'))) { score += 0.9; flags.push('known_phishing_domain'); }
  if (hostname.split('.').length - 2 >= 3)                     { score += 0.2;  flags.push('excessive_subdomains'); }
  if (SUSPICIOUS_TLDS.some(t => hostname.endsWith(t)))         { score += 0.25; flags.push('suspicious_tld'); }
  if ((hostname.match(/-/g) || []).length >= 3)                { score += 0.15; flags.push('excessive_hyphens'); }
  if (/[^\x00-\x7F]/.test(hostname))                          { score += 0.4;  flags.push('unicode_homograph'); }
  if (fullUrl.indexOf('@') > fullUrl.indexOf('//') + 2)         { score += 0.25; flags.push('at_symbol_in_url'); }
  if (/%2f|%5c|redirect=|returnurl=|next=|url=/i.test(fullUrl)) { score += 0.12; flags.push('encoded_redirect'); }
  if (parsed.search && parsed.search.split('&').length >= 6)    { score += 0.08; flags.push('many_query_params'); }
  if (/\/(login|signin|verify|secure|account\/update)/.test(path)) { score += 0.05; flags.push('login_path'); }

  const parts = hostname.split('.');
  const reg   = parts.slice(-2).join('.');
  const sub   = parts.slice(0,-2).join('.');
  for (const brand of TRUSTED_BRANDS) {
    if (sub.includes(brand) && !reg.startsWith(brand)) { score += 0.45; flags.push('brand_spoofed:' + brand); break; }
    if ((reg.startsWith(brand + '-') || reg.includes('-' + brand)) && reg !== brand + '.com') {
      score += 0.35;
      flags.push('brand_lookalike_domain:' + brand);
      break;
    }
  }

  const hits = PHISHING_KW.filter(k => fullUrl.includes(k)).length;
  if (hits >= 3)         { score += 0.2;  flags.push('phishing_keywords:' + hits); }
  if (rawUrl.length > 200) { score += 0.1; flags.push('long_url'); }

  return { score: Math.min(parseFloat(score.toFixed(3)), 1.0), flags };
}

// ── API call ──────────────────────────────────────────────────────────────────

async function sendToAPI(url, local) {
  try {
    const apiConfig = await getApiConfig();
    const ctrl = new AbortController();
    const t    = setTimeout(() => ctrl.abort(), REQUEST_TIMEOUT_MS);
    const res  = await fetch(apiConfig.endpoint, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', 'X-Extension-Version': chrome.runtime.getManifest().version },
      body:    JSON.stringify({ url, local_score: local.score, local_flags: local.flags, timestamp: Date.now() }),
      signal:  ctrl.signal,
    });
    clearTimeout(t);
    if (!res.ok) return null;
    const data = await res.json();
    if (typeof data?.risk_score !== 'number' || data.risk_score < 0 || data.risk_score > 1) return null;
    return data;
  } catch { return null; }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function storageLocalGet(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, resolve);
  });
}

function storageLocalSet(values) {
  return new Promise((resolve) => {
    chrome.storage.local.set(values, resolve);
  });
}

async function getApiConfig() {
  const stored = await storageLocalGet(['guardaiApiEnv']);
  const env = API_ENVIRONMENTS[stored.guardaiApiEnv] ? stored.guardaiApiEnv : DEFAULT_API_ENV;
  return {
    env,
    label: API_ENVIRONMENTS[env].label,
    endpoint: API_ENVIRONMENTS[env].endpoint,
  };
}

async function setApiEnv(env) {
  if (!API_ENVIRONMENTS[env]) {
    return getApiConfig();
  }
  await storageLocalSet({ guardaiApiEnv: env });
  return getApiConfig();
}

function checkRateLimit() {
  const now = Date.now();
  if (now - windowStart > 60000) { requestCount = 0; windowStart = now; }
  if (requestCount >= MAX_REQUESTS_PER_MIN) return false;
  requestCount++;
  return true;
}

function pruneCache() {
  const now = Date.now();
  for (const [url, e] of urlCache.entries()) {
    if (now - e.timestamp > URL_CACHE_TTL_MS) urlCache.delete(url);
  }
}

function dedupeFlags(flags) {
  const seen = new Set();
  return flags.filter((flag) => {
    if (seen.has(flag)) return false;
    seen.add(flag);
    return true;
  });
}

function scorePageSignals(signals) {
  const flags = [];
  let score = 0;

  if (!signals || typeof signals !== 'object') {
    return { score, flags };
  }

  if (signals.externalFormAction) {
    score += 0.35;
    flags.push('page_external_form_action');
  }
  if (signals.hasPaymentFields) {
    score += 0.30;
    flags.push('page_payment_fields');
  }
  if (signals.hasPasswordField && signals.hasEmailField) {
    score += 0.10;
    flags.push('page_login_form');
  }
  const suspiciousKeywordCount = Array.isArray(signals.suspiciousKeywords)
    ? signals.suspiciousKeywords.length
    : Number(signals.suspiciousKeywordCount || 0);
  if (suspiciousKeywordCount > 0) {
    score += Math.min(0.35, 0.20 + (suspiciousKeywordCount * 0.05));
    flags.push('page_suspicious_language');
  }
  if (signals.formCount > 5) {
    score += 0.05;
    flags.push('page_many_forms');
  }

  return { score: Math.min(parseFloat(score.toFixed(3)), 1.0), flags };
}

async function applyPageSignals(tabId, url, signals) {
  if (typeof tabId !== 'number' || !url || (!url.startsWith('http://') && !url.startsWith('https://'))) return;

  const cached = urlCache.get(url);
  const base = cached || analyzeURL(url);
  const page = scorePageSignals(signals);
  const score = Math.min(1.0, Math.max(base.score, page.score, base.score + (page.score * 0.75)));
  const flags = dedupeFlags([...(base.flags || []), ...page.flags]);

  urlCache.set(url, { score, flags, timestamp: Date.now() });
  pruneCache();
  await applyRisk(tabId, url, score, flags, 'page');
}

async function applyRisk(tabId, url, score, flags, source) {
  try {
    await chrome.storage.session.set({ ['tab_' + tabId]: { url, score, flags, source, analyzedAt: Date.now() } });
    if (score >= RISK_THRESHOLD_BLOCK) {
      chrome.action.setBadgeText({ text: '!', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#DC2626', tabId });
    } else if (score >= RISK_THRESHOLD_WARN) {
      chrome.action.setBadgeText({ text: '!', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#D97706', tabId });
    } else {
      chrome.action.setBadgeText({ text: '✓', tabId });
      chrome.action.setBadgeBackgroundColor({ color: '#16A34A', tabId });
    }
  } catch(e) { console.warn('[GuardAI]', e.message); }
}

// ── Main evaluation ───────────────────────────────────────────────────────────

async function evaluateURL(url, tabId) {
  try {
    const cached = urlCache.get(url);
    if (cached && Date.now() - cached.timestamp < URL_CACHE_TTL_MS) {
      await applyRisk(tabId, url, cached.score, cached.flags, 'cache');
      return;
    }
    const local = analyzeURL(url);
    await applyRisk(tabId, url, local.score, local.flags, 'local');
    urlCache.set(url, { score: local.score, flags: local.flags, timestamp: Date.now() });
    pruneCache();

    if (checkRateLimit()) {
      const api = await sendToAPI(url, local);
      if (api) {
        const score = api.risk_score;
        const flags = api.flags || local.flags;
        urlCache.set(url, { score, flags, timestamp: Date.now() });
        await applyRisk(tabId, url, score, flags, 'api');
      }
    }
  } catch(err) { console.error('[GuardAI]', err.message); }
}

// ── Listeners ─────────────────────────────────────────────────────────────────

chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0) return;
  if (!['link','typed','generated','start_page'].includes(details.transitionType)) return;
  if (!details.url.startsWith('http://') && !details.url.startsWith('https://')) return;
  await evaluateURL(details.url, details.tabId);
});

chrome.alarms.create('keepAlive', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener(() => {});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_TAB_RISK') {
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs[0]) { sendResponse(null); return; }
      const data = await chrome.storage.session.get('tab_' + tabs[0].id);
      sendResponse(data['tab_' + tabs[0].id] || null);
    });
    return true;
  }

  if (msg.type === 'GET_API_CONFIG') {
    getApiConfig().then(sendResponse).catch(() => sendResponse(null));
    return true;
  }

  if (msg.type === 'SET_API_ENV') {
    (async () => {
      const config = await setApiEnv(msg.env);
      chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
        try {
          if (tabs[0] && tabs[0].url && tabs[0].url.startsWith('http')) {
            urlCache.delete(tabs[0].url);
            await evaluateURL(tabs[0].url, tabs[0].id);
          }
          sendResponse(config);
        } catch (err) {
          console.warn('[GuardAI]', err.message);
          sendResponse(config);
        }
      });
    })().catch(() => sendResponse(null));
    return true;
  }

  if (msg.type === 'PAGE_ANALYSIS') {
    (async () => {
      const tabId = sender.tab && sender.tab.id;
      const url = msg.url || sender.url || '';
      await applyPageSignals(tabId, url, msg.signals);
      sendResponse({ ok: true });
    })().catch((err) => {
      console.warn('[GuardAI]', err.message);
      sendResponse({ ok: false });
    });
    return true;
  }
});

console.info('[GuardAI] Service worker ready.');
