#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib.sh"

load_env_file "${1:-}"
require_env API_HOSTNAME
require_command curl

BASE_URL="https://${API_HOSTNAME}"

echo "== Health =="
curl -fsS "$BASE_URL/health"
echo

echo "== Ready =="
curl -fsS "$BASE_URL/ready"
echo

echo "== Analyze known phishing test URL =="
curl -fsS -X POST "$BASE_URL/v1/analyze" \
  -H "Content-Type: application/json" \
  -H "X-Extension-Version: 0.1.0" \
  -d '{"url":"http://paypa1.com/login","local_score":0.0,"local_flags":[]}'
echo

