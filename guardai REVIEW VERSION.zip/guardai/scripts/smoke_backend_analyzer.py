import asyncio
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BACKEND = ROOT / "backend"
sys.path.insert(0, str(BACKEND))

from app.services.analyzer import analyze  # noqa: E402
from app.services.url_safety import validate_public_http_url  # noqa: E402


CASES = [
    {
        "name": "safe_url",
        "url": "https://www.google.com",
        "local_score": 0.0,
        "min_score": 0.0,
        "max_score": 0.49,
        "flag": None,
    },
    {
        "name": "known_phishing",
        "url": "http://paypa1.com/login",
        "local_score": 0.0,
        "min_score": 0.85,
        "max_score": 1.0,
        "flag": "known_phishing_domain",
    },
    {
        "name": "known_phishing_subdomain",
        "url": "https://login.paypa1.com",
        "local_score": 0.0,
        "min_score": 0.85,
        "max_score": 1.0,
        "flag": "known_phishing_domain",
    },
    {
        "name": "brand_spoofing",
        "url": "https://paypal.fake-bank.com/verify",
        "local_score": 0.0,
        "min_score": 0.5,
        "max_score": 1.0,
        "flag": "brand_spoofed:paypal",
    },
    {
        "name": "local_score_preserved",
        "url": "https://example.com",
        "local_score": 0.8,
        "min_score": 0.8,
        "max_score": 1.0,
        "flag": None,
    },
]


async def main() -> int:
    failures = 0

    for case in CASES:
        result = await analyze(case["url"], case["local_score"], [])
        score = result["risk_score"]
        flags = result["flags"]
        score_ok = case["min_score"] <= score <= case["max_score"]
        flag_ok = case["flag"] is None or case["flag"] in flags
        ok = score_ok and flag_ok

        label = "PASS" if ok else "FAIL"
        flag_text = ",".join(flags) if flags else "none"
        print(f"{label} {case['name']}: {round(score * 100)}/100 [{flag_text}]")

        if not ok:
            failures += 1
            print(
                "  Expected "
                f"{round(case['min_score'] * 100)}-{round(case['max_score'] * 100)}/100"
                + (f" with flag {case['flag']}" if case["flag"] else "")
            )

    blocked_urls = [
        "http://127.0.0.1:8000/health",
        "http://localhost:8000/health",
        "http://10.0.0.1/admin",
        "http://192.168.1.1/login",
        "http://169.254.169.254/latest/meta-data/",
        "http://[::1]/",
    ]

    for url in blocked_urls:
        try:
            validate_public_http_url(url)
        except ValueError:
            print(f"PASS blocked_internal_url: {url}")
        else:
            failures += 1
            print(f"FAIL blocked_internal_url: {url}")

    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
