"""
GuardAI – Rate Limiter

Prevents abuse: no single IP can hammer our API.
Uses slowapi (a FastAPI wrapper around limits library).

Current limit: 60 requests per minute per IP.
This is generous for a real user but blocks scrapers and DDoS attempts.
"""

from slowapi import Limiter
from slowapi.util import get_remote_address
from app.core.config import settings

# get_remote_address extracts the caller's IP from the request
limiter = Limiter(
    key_func=get_remote_address,
    default_limits=[settings.RATE_LIMIT],
)
