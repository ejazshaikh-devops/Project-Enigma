"""
GuardAI – Backend Tests

Run with: pytest tests/
These tests verify the analyzer works correctly WITHOUT needing
a database or running server — pure logic tests.
"""

import pytest
import asyncio
from app.services.analyzer import analyze


# ── Helpers ───────────────────────────────────────────────────────────────────

async def score(url, local_score=0.0, local_flags=None):
    result = await analyze(url, local_score, local_flags or [])
    return result["risk_score"], result["flags"]


# ── Tests ─────────────────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_safe_url():
    risk, flags = await score("https://www.google.com")
    assert risk < 0.5, "Google.com should be low risk"

@pytest.mark.asyncio
async def test_known_phishing_domain():
    risk, flags = await score("http://paypa1.com/login")
    assert risk >= 0.85, "Known phishing domain should be high risk"
    assert "known_phishing_domain" in flags

@pytest.mark.asyncio
async def test_known_phishing_subdomain():
    risk, flags = await score("https://login.paypa1.com")
    assert risk >= 0.85, "Known phishing subdomains should stay high risk"
    assert "known_phishing_domain" in flags

@pytest.mark.asyncio
async def test_suspicious_tld():
    risk, flags = await score("https://secure-login.tk")
    assert "suspicious_tld" in flags

@pytest.mark.asyncio
async def test_brand_spoofing():
    risk, flags = await score("https://paypal.fake-bank.com/verify")
    assert any("brand_spoofed" in f for f in flags)
    assert risk >= 0.5

@pytest.mark.asyncio
async def test_local_score_contributes():
    # Even if backend finds nothing, a high local score lifts the final score
    risk, _ = await score("https://example.com", local_score=0.8)
    assert risk >= 0.25, "High local score should contribute to final score"

@pytest.mark.asyncio
async def test_ssrf_blocked():
    from app.api.schemas import AnalyzeRequest
    with pytest.raises(Exception):
        AnalyzeRequest(
            url="http://169.254.169.254/latest/meta-data/",
            local_score=0.0,
            local_flags=[],
        )

@pytest.mark.parametrize("url", [
    "http://127.0.0.1:8000/health",
    "http://localhost:8000/health",
    "http://10.0.0.1/admin",
    "http://192.168.1.1/login",
    "http://[::1]/",
])
def test_internal_network_urls_blocked(url):
    from app.services.url_safety import validate_public_http_url
    with pytest.raises(Exception):
        validate_public_http_url(url)
