"""
GuardAI – URL Analysis Service

This is the core "thinking" layer of the backend.
It combines signals from multiple sources into one final risk score:

  1. Local score  — fast heuristics already computed by the extension
  2. Known list   — hardcoded known-bad domains (Phase 1 placeholder)
  3. URL entropy  — measures how random/generated the domain looks
  4. TLD check    — high-risk domain extensions
  5. Future: ML model (Phase 4), WHOIS age, VirusTotal API, etc.

WHY SEPARATE FROM routes.py?
Business logic should never live in the route handler.
This way we can test the analysis independently, swap out the ML model,
or add new signal sources without touching the API layer.
"""

import math
from urllib.parse import urlparse
from typing import Dict, List


# ── Known phishing domains (Phase 1 — hardcoded placeholder) ─────────────────
# Phase 3 will replace this with a PostgreSQL lookup of millions of entries
# pulled from threat intelligence feeds (PhishTank, OpenPhish, etc.)

KNOWN_PHISHING_DOMAINS = {
    "paypa1.com",
    "app1e-id.com",
    "g00gle.com",
    "netfl1x-login.com",
    "amaz0n-secure.com",
    "secure-amazon-verify.xyz",
    "apple-id-verify.tk",
    "bankofamerica-secure.ml",
    "signin-paypal-secure.com",
}

# ── High-risk TLDs ────────────────────────────────────────────────────────────

SUSPICIOUS_TLDS = {
    ".tk", ".ml", ".ga", ".cf", ".gq",
    ".xyz", ".top", ".click", ".loan",
    ".work", ".date", ".faith", ".racing",
    ".review", ".stream", ".gdn",
}

# ── Trusted brand names that are commonly spoofed ────────────────────────────

TRUSTED_BRANDS = [
    "paypal", "apple", "microsoft", "amazon", "netflix",
    "google", "facebook", "instagram", "twitter", "linkedin",
    "bankofamerica", "chase", "wellsfargo", "hsbc", "barclays",
    "coinbase", "binance", "metamask", "upi", "paytm", "hdfc",
    "icici", "sbi", "axis",
]


async def analyze(url: str, local_score: float, local_flags: List[str]) -> Dict:
    """
    Main analysis function. Runs all checks and returns a combined score.

    Parameters:
        url          – Full URL string (already validated by Pydantic)
        local_score  – Score pre-computed by the extension (0.0 – 1.0)
        local_flags  – Flags already detected by the extension

    Returns:
        { "risk_score": float, "flags": list[str] }
    """

    flags = list(local_flags)  # Start with what the extension found
    backend_score = 0.0

    try:
        parsed   = urlparse(url)
        hostname = (parsed.hostname or "").lower()
    except Exception:
        return {"risk_score": 0.95, "flags": ["invalid_url"]}

    # Run all checks — order matters (cheap checks first)

    registerable_domain = _registrable_domain(hostname)

    # 1. Known bad domain — instant high score
    if hostname in KNOWN_PHISHING_DOMAINS or registerable_domain in KNOWN_PHISHING_DOMAINS:
        flags.append("known_phishing_domain")
        backend_score = max(backend_score, 0.95)

    # 2. Domain entropy — how random does the domain look?
    domain_label = hostname.split(".")[0]  # "paypal" from "paypal.com"
    entropy = _shannon_entropy(domain_label)

    if entropy > 4.2:
        flags.append("very_high_domain_entropy")
        backend_score += 0.25
    elif entropy > 3.5:
        flags.append("high_domain_entropy")
        backend_score += 0.12

    # 3. TLD check (backend version — more complete than extension)
    for tld in SUSPICIOUS_TLDS:
        if hostname.endswith(tld):
            if "suspicious_tld" not in flags:
                flags.append("suspicious_tld")
                backend_score += 0.2
            break

    # 4. Brand name spoofed in subdomain
    # e.g. "paypal.fake-site.com" — paypal is in subdomain, not the real domain
    parts      = hostname.split(".")
    registerable = registerable_domain    # real domain: "fake-site.com"
    subdomains   = ".".join(parts[:-2])   # subdomain part: "paypal"

    for brand in TRUSTED_BRANDS:
        if brand in subdomains and not registerable.startswith(brand):
            flags.append(f"brand_spoofed:{brand}")
            backend_score += 0.55
            break

    # 5. Punycode / IDN homograph attack
    # Attackers register xn-- domains that look like real ones in browsers
    if "xn--" in hostname:
        flags.append("punycode_domain")
        backend_score += 0.35

    # 6. Numeric-heavy domain (generated domains often use numbers)
    digit_ratio = sum(c.isdigit() for c in domain_label) / max(len(domain_label), 1)
    if digit_ratio > 0.4 and len(domain_label) > 4:
        flags.append("numeric_heavy_domain")
        backend_score += 0.15

    # ── Combine scores ────────────────────────────────────────────────────────
    # Weighted blend: 35% local (fast heuristics) + 65% backend (deeper checks)
    # If either source alone is very high, the combined score stays high.
    combined = (local_score * 0.35) + (min(backend_score, 1.0) * 0.65)
    combined = max(combined, local_score, backend_score)
    combined = round(min(combined, 1.0), 4)

    # Deduplicate flags
    seen  = set()
    flags = [f for f in flags if not (f in seen or seen.add(f))]

    return {"risk_score": combined, "flags": flags}


def _registrable_domain(hostname: str) -> str:
    """
    Returns the last two labels as a lightweight registerable-domain estimate.

    This is enough for the prototype's local heuristics. A production threat
    database should switch to Public Suffix List parsing before launch.
    """
    parts = hostname.split(".")
    if len(parts) < 2:
        return hostname
    return ".".join(parts[-2:])


def _shannon_entropy(text: str) -> float:
    """
    Calculates the Shannon entropy of a string.

    Entropy measures randomness. High entropy = random-looking string.

    A real word like "paypal" → ~2.5
    A generated domain like "x7k2p9mq" → ~3.8+

    Phishing tools often auto-generate domains, so high entropy is a
    meaningful signal even without any other checks.
    """
    if not text:
        return 0.0

    freq = {}
    for char in text:
        freq[char] = freq.get(char, 0) + 1

    length  = len(text)
    entropy = 0.0
    for count in freq.values():
        p        = count / length
        entropy -= p * math.log2(p)

    return entropy
