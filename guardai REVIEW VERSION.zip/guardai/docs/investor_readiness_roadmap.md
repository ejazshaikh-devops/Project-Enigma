# GuardAI Investor Readiness Roadmap

GuardAI is currently a working proof of concept, not a production product.
That is a good starting point: the goal is to move from "it works on my
machine" to "users trust it, data proves it, investors can understand it."

## Current Score

Current readiness: 3/10

What is real today:
- Chrome extension prototype exists.
- Local URL heuristics work.
- FastAPI backend skeleton exists.
- Basic analyzer tests exist.
- Security-first ideas are already present in the architecture.
- Local demo pages and extension scoring smoke tests exist.
- Backend analyzer and URL safety smoke checks exist.
- AWS/EKS staging deployment scaffolding exists.
- Extension can switch between local, staging, and production API endpoints.

What is not real enough yet:
- No production deployment.
- No Chrome Web Store listing.
- No real user installs.
- No measured detection accuracy.
- No threat feed ingestion.
- No analytics dashboard.
- No trained ML model.
- No investor metrics.

## Level 3: Reliable Prototype

Goal: the extension and backend behave consistently during demos.

Acceptance criteria:
- Done: backend high-confidence phishing signals cannot be diluted into low scores.
- Done: popup shows the same verdict as the background worker.
- Done: page form warnings work before the user submits credentials.
- Done: content-script signals are privacy-preserving.
- Done: local smoke tests are documented and repeatable.

## Level 4: Local Beta

Goal: a small trusted group can test GuardAI without engineering help.

Acceptance criteria:
- In progress: one-command backend smoke checks work.
- In progress: AWS staging manifests and CI/CD workflow template exist.
- One-command backend startup works.
- Extension install steps are clear.
- Demo phishing URLs are documented.
- Errors fail safely and clearly.
- Basic privacy policy draft exists.

## Level 5: Public Beta

Goal: the product can be shared outside friends and family.

Acceptance criteria:
- Backend is deployed to a real HTTPS API.
- Extension uses production API config.
- Chrome Web Store submission package is ready.
- User feedback collection exists.
- Basic event metrics exist without collecting sensitive data.

## Level 6: Threat Intelligence

Goal: GuardAI becomes more than local heuristics.

Acceptance criteria:
- Threat database schema exists.
- PhishTank/OpenPhish-style feed ingestion exists.
- URL/domain lookups are cached.
- False-positive review flow exists.
- Daily threat update job runs.

## Level 7: Measured Detection

Goal: accuracy can be discussed honestly.

Acceptance criteria:
- Labeled phishing and legitimate URL datasets are stored.
- Evaluation script reports precision, recall, F1, and false-positive rate.
- Baseline heuristic model is compared against ML model.
- Demo report shows examples caught and missed.

## Level 8: User Trust

Goal: real users can understand and trust the product.

Acceptance criteria:
- Warning UI explains risk in plain language.
- Users can report false positives and missed scams.
- Privacy policy and data handling are explicit.
- Extension permissions are minimal and justified.
- Support/contact path exists.

## Level 9: Investor Story

Goal: investors see a credible business, not only code.

Acceptance criteria:
- 500+ installs or a believable waitlist.
- Weekly active usage trend is visible.
- Detection volume and report volume are visible.
- India-specific scam examples are documented.
- Competitor and moat slide is clear.

## Level 10: Investor-Ready

Goal: GuardAI can survive serious diligence.

Acceptance criteria:
- Live demo works reliably.
- Production backend is monitored.
- Detection metrics are real and reproducible.
- User traction is real.
- Security and privacy posture is documented.
- Pitch deck uses measured numbers, not guesses.

## Next Three Baby Steps

1. Draft the privacy policy and Chrome Web Store data-use wording.
2. Create a simple beta feedback flow for testers.
3. Fill AWS staging secrets and run the GitHub Actions deployment.
