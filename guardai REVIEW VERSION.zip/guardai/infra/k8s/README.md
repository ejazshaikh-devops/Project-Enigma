# GuardAI Kubernetes Manifests

These manifests deploy the GuardAI backend API to Kubernetes.

## Layout

- `base/` contains reusable API deployment, service, HPA, and ingress manifests.
- `overlays/staging/` contains staging-specific image, CORS, hostname, and ACM certificate values.

Secrets are not committed. Use `base/secret.example.yaml` as a reference only.

## Render Locally

```bash
kubectl kustomize guardai/infra/k8s/overlays/staging
```

If placeholders are still present, replace them before deploying:

- ECR image repo in `overlays/staging/kustomization.yaml`
- Chrome extension ID in `overlays/staging/configmap.patch.yaml`
- ACM certificate ARN in `overlays/staging/ingress.patch.yaml`
- API hostname in `overlays/staging/ingress.patch.yaml`

## Apply

```bash
kubectl apply -k guardai/infra/k8s/overlays/staging
kubectl -n guardai-staging rollout status deployment/guardai-api
```

Create the `guardai-api-secrets` secret before applying the deployment.

For AWS staging, prefer the scripts in `guardai/infra/aws/scripts/` because
they render these manifests with your ECR, hostname, certificate, and extension
values.
