# GuardAI AWS Staging Deployment

This is the first cloud deployment path for GuardAI. It assumes:

- AWS account access
- ECR repository for the backend image
- EKS cluster with AWS Load Balancer Controller installed
- ACM certificate for the staging API hostname
- PostgreSQL database, preferably RDS, reachable from the EKS cluster
- GitHub repository with OIDC access to AWS

## Recommended Staging Shape

Use this architecture first:

- Chrome extension calls `https://api-staging.guardai.io/v1/analyze`
- AWS ALB terminates HTTPS
- ALB forwards to EKS service `guardai-api`
- EKS runs 2 API pods
- API connects to RDS PostgreSQL through `DATABASE_URL`
- Container image is stored in ECR

Do not run production PostgreSQL inside Kubernetes for this stage. RDS is the
cleaner path for backups, patching, and investor-readiness later.

## Required GitHub Secrets

Add these in GitHub repository settings:

| Secret | Example |
| ------ | ------- |
| `AWS_ROLE_ARN` | `arn:aws:iam::123456789012:role/github-guardai-deploy` |
| `AWS_REGION` | `ap-south-1` |
| `ECR_REPOSITORY` | `guardai-api` |
| `EKS_CLUSTER_NAME` | `guardai-staging` |
| `API_DATABASE_URL` | `postgresql://guardai:password@rds-host:5432/guardai` |
| `API_SECRET_KEY` | long random secret |
| `CHROME_EXTENSION_ID` | Chrome extension ID after publishing or local ID for testing |
| `API_HOSTNAME` | `api-staging.guardai.io` |
| `ACM_CERTIFICATE_ARN` | ACM certificate ARN for the hostname |

## One-Time AWS Setup Checklist

1. Create ECR repository:

```bash
aws ecr create-repository --repository-name guardai-api
```

2. Create or select an EKS cluster.

3. Install the AWS Load Balancer Controller in the cluster.

4. Create an RDS PostgreSQL database or reuse a staging database.

5. Make sure EKS pod networking/security groups can reach RDS.

6. Create an ACM certificate for `api-staging.guardai.io`.

7. Point DNS for `api-staging.guardai.io` to the ALB after the ingress creates it.

8. Configure GitHub OIDC role with permissions for ECR and EKS deployment.
   Use `github_actions_iam_policy.example.json` as a starting point, then map
   the role into Kubernetes RBAC or an EKS access entry so it can apply manifests
   in the `guardai-staging` namespace.

## Manual Kubernetes Deploy

Use this flow if you want to deploy from your local machine first.

```bash
cp guardai/infra/aws/env/staging.env.example guardai/infra/aws/env/staging.env
```

Edit `guardai/infra/aws/env/staging.env`, then run:

```bash
./guardai/infra/aws/scripts/preflight_staging.sh guardai/infra/aws/env/staging.env
./guardai/infra/aws/scripts/deploy_staging.sh guardai/infra/aws/env/staging.env
./guardai/infra/aws/scripts/smoke_staging_api.sh guardai/infra/aws/env/staging.env
```

The deploy script will:

- ensure the ECR repository exists
- build and push the backend Docker image
- update kubeconfig for EKS
- create/update the Kubernetes secret
- render manifests with your staging values
- apply the manifests
- wait for rollout

You can render manifests without applying them:

```bash
./guardai/infra/aws/scripts/render_staging_manifests.sh guardai/infra/aws/env/staging.env
```

## Smoke Test After Deploy

The helper script runs the same checks:

```bash
./guardai/infra/aws/scripts/smoke_staging_api.sh guardai/infra/aws/env/staging.env
```

Manual equivalent:

```bash
curl https://api-staging.guardai.io/health
curl https://api-staging.guardai.io/ready
curl -X POST https://api-staging.guardai.io/v1/analyze \
  -H "Content-Type: application/json" \
  -d '{"url":"http://paypa1.com/login","local_score":0.0,"local_flags":[]}'
```

Expected analyze result: verdict should be `dangerous` and include
`known_phishing_domain`.

## Extension Cutover

After the API works over HTTPS:

1. Reload the extension in `chrome://extensions`.
2. Open the GuardAI popup.
3. Change `API` from `Local` to `Staging`.
4. Open a new website or reload the current tab.
5. Confirm the API sees traffic at `https://api-staging.guardai.io/v1/analyze`.

The extension keeps the selected API environment in `chrome.storage.local`.
