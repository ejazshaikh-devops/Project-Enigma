#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib.sh"

ENV_FILE="${1:-}"
load_env_file "$ENV_FILE"
require_env \
  AWS_REGION \
  AWS_ACCOUNT_ID \
  ECR_REPOSITORY \
  EKS_CLUSTER_NAME \
  K8S_NAMESPACE \
  API_HOSTNAME \
  ACM_CERTIFICATE_ARN \
  CHROME_EXTENSION_ID \
  API_DATABASE_URL \
  API_SECRET_KEY

require_command aws
require_command kubectl
require_command docker
verify_aws_account

echo "== Build and push API image =="
"$SCRIPT_DIR/build_push_api_image.sh" "$ENV_FILE"

echo
echo "== Configure kubeconfig =="
aws eks update-kubeconfig --region "$AWS_REGION" --name "$EKS_CLUSTER_NAME"

echo
echo "== Ensure namespace and secret =="
kubectl create namespace "$K8S_NAMESPACE" --dry-run=client -o yaml | kubectl apply -f -
kubectl -n "$K8S_NAMESPACE" create secret generic guardai-api-secrets \
  --from-literal=DATABASE_URL="$API_DATABASE_URL" \
  --from-literal=SECRET_KEY="$API_SECRET_KEY" \
  --dry-run=client -o yaml | kubectl apply -f -

echo
echo "== Apply staging manifests =="
"$SCRIPT_DIR/render_staging_manifests.sh" "$ENV_FILE" | kubectl apply -f -

echo
echo "== Wait for rollout =="
kubectl -n "$K8S_NAMESPACE" rollout status deployment/guardai-api --timeout=180s

echo
echo "Deployment complete. Run:"
echo "  $SCRIPT_DIR/smoke_staging_api.sh $ENV_FILE"
