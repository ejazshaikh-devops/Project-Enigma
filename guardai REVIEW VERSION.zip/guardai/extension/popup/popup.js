// GuardAI – popup.js
// External file required by CSP (script-src 'self' blocks inline scripts)
// No imports. No modules. Plain ES5-compatible JavaScript.

var BAD_TLDS = ['.tk','.ml','.ga','.cf','.gq','.xyz','.top','.click','.loan','.work','.date','.faith','.racing'];
var BRANDS   = ['paypal','apple','microsoft','amazon','netflix','google','facebook','instagram','twitter','linkedin','bankofamerica','chase','wellsfargo','hsbc','barclays','coinbase','binance','paytm','hdfc','icici','sbi','axis'];
var KW       = ['login','signin','verify','secure','account','update','banking','confirm','password','credential','support','suspended','urgent'];
var KNOWN_BAD= {'paypa1.com':1,'app1e-id.com':1,'g00gle.com':1,'netfl1x-login.com':1,'secure-amazon-verify.xyz':1};

function scan(rawUrl) {
  var flags = [];
  var score = 0.03;
  var p;
  try { p = new URL(rawUrl); } catch(e) { return {score:0.9, flags:['malformed_url']}; }

  var h = p.hostname.toLowerCase();
  var u = rawUrl.toLowerCase();
  var path = p.pathname.toLowerCase();

  if (p.protocol === 'http:')                                        { score += 0.15; flags.push('no_https'); }
  if (/^(\d{1,3}\.){3}\d{1,3}$/.test(h))                           { score += 0.35; flags.push('ip_address_host'); }
  if (KNOWN_BAD[h.split('.').slice(-2).join('.')])                   { score += 0.9;  flags.push('known_phishing_domain'); }
  if (h.split('.').length - 2 >= 3)                                 { score += 0.2;  flags.push('excessive_subdomains'); }
  if (BAD_TLDS.some(function(t){ return h.slice(-t.length) === t; })){ score += 0.25; flags.push('suspicious_tld'); }
  if ((h.match(/-/g) || []).length >= 3)                            { score += 0.15; flags.push('excessive_hyphens'); }
  if (/[^\x00-\x7F]/.test(h))                                      { score += 0.4;  flags.push('unicode_homograph'); }
  if (u.indexOf('@') > u.indexOf('//') + 2)                          { score += 0.25; flags.push('at_symbol_in_url'); }
  if (/%2f|%5c|redirect=|returnurl=|next=|url=/i.test(u))            { score += 0.12; flags.push('encoded_redirect'); }
  if (p.search && p.search.split('&').length >= 6)                   { score += 0.08; flags.push('many_query_params'); }
  if (/\/(login|signin|verify|secure|account\/update)/.test(path))  { score += 0.05; flags.push('login_path'); }

  var parts = h.split('.');
  var reg   = parts.slice(-2).join('.');
  var sub   = parts.slice(0, -2).join('.');
  for (var i = 0; i < BRANDS.length; i++) {
    if (sub.indexOf(BRANDS[i]) !== -1 && reg.indexOf(BRANDS[i]) !== 0) {
      score += 0.45;
      flags.push('brand_spoofed:' + BRANDS[i]);
      break;
    }
    if ((reg.indexOf(BRANDS[i] + '-') === 0 || reg.indexOf('-' + BRANDS[i]) !== -1) && reg !== BRANDS[i] + '.com') {
      score += 0.35;
      flags.push('brand_lookalike_domain:' + BRANDS[i]);
      break;
    }
  }

  var hits = 0;
  for (var j = 0; j < KW.length; j++) {
    if (u.indexOf(KW[j]) !== -1) hits++;
  }
  if (hits >= 3)            { score += 0.2; flags.push('phishing_keywords:' + hits); }
  if (rawUrl.length > 200)  { score += 0.1; flags.push('long_url'); }

  var final = parseFloat(score.toFixed(3));
  if (final > 1) final = 1;
  return { score: final, flags: flags };
}

function labelFlag(f) {
  var m = {
    'no_https':             'No HTTPS encryption',
    'ip_address_host':      'IP address used as domain',
    'known_phishing_domain':'Known phishing domain',
    'excessive_subdomains': 'Suspicious subdomain chain',
    'suspicious_tld':       'High-risk domain extension',
    'excessive_hyphens':    'Too many hyphens in domain',
    'unicode_homograph':    'Fake look-alike characters',
    'long_url':             'Unusually long URL',
    'malformed_url':        'Malformed URL',
    'login_path':           'Login or verification path',
    'at_symbol_in_url':     'Hidden destination trick',
    'encoded_redirect':     'Redirect pattern in URL',
    'many_query_params':    'Too many tracking/query parts',
    'page_external_form_action': 'Form submits to another domain',
    'page_payment_fields':  'Payment fields detected',
    'page_login_form':      'Login form detected',
    'page_suspicious_language': 'Suspicious page language',
    'page_many_forms':      'Unusual number of forms'
  };
  if (f.indexOf('brand_spoofed:') === 0) return '"' + f.split(':')[1] + '" brand impersonated';
  if (f.indexOf('brand_lookalike_domain:') === 0) return '"' + f.split(':')[1] + '" look-alike domain';
  if (f.indexOf('phishing_keywords:') === 0) return f.split(':')[1] + ' phishing keywords found';
  return m[f] || f;
}

function showResult(url, score, flags) {
  var card  = document.getElementById('card');
  var icon  = document.getElementById('icon');
  var title = document.getElementById('title');
  var sub   = document.getElementById('sub');
  var urlEl = document.getElementById('url-val');
  var cardScore = document.getElementById('card-score');
  var normalizedScore = Number(score);
  if (!isFinite(normalizedScore)) normalizedScore = 0;
  normalizedScore = Math.max(0, Math.min(1, normalizedScore));
  var pct  = Math.round(normalizedScore * 100);

  urlEl.textContent = url || '—';

  if (normalizedScore >= 0.85) {
    card.className    = 'card danger';
    icon.textContent  = '🛑';
    title.textContent = 'Dangerous page';
    sub.textContent   = 'Do NOT enter passwords or payment details';
  } else if (normalizedScore >= 0.5) {
    card.className    = 'card warn';
    icon.textContent  = '⚠️';
    title.textContent = 'Suspicious page';
    sub.textContent   = 'Be careful before entering any details';
  } else {
    card.className    = 'card safe';
    icon.textContent  = '✓';
    title.textContent = 'This page looks safe';
    sub.textContent   = 'No threats detected';
  }

  cardScore.textContent = 'Risk Score: ' + pct + '/100';

  var wrap = document.getElementById('score-wrap');
  var pctEl= document.getElementById('score-pct');
  var fill = document.getElementById('fill');
  var urlStatus = document.getElementById('url-status');
  wrap.classList.remove('hide');
  pctEl.textContent   = pct + '/100';
  fill.style.width    = pct + '%';
  fill.style.background = '#EF4444';

  if (normalizedScore >= 0.85) {
    urlStatus.textContent = 'Dangerous URL';
    urlStatus.className = 'url-status danger';
  } else if (normalizedScore >= 0.5) {
    urlStatus.textContent = 'Unusual URL';
    urlStatus.className = 'url-status unusual';
  } else {
    urlStatus.textContent = 'Usual URL';
    urlStatus.className = 'url-status usual';
  }

  var fw = document.getElementById('flags-wrap');
  var ul = document.getElementById('flags-list');
  fw.classList.add('hide');
  ul.innerHTML = '';
  if (flags && flags.length > 0) {
    fw.classList.remove('hide');
    for (var i = 0; i < flags.length; i++) {
      var li = document.createElement('li');
      li.textContent = labelFlag(flags[i]);
      ul.appendChild(li);
    }
  }
}

function showError(msg) {
  document.getElementById('icon').textContent  = '—';
  document.getElementById('title').textContent = msg || 'Cannot scan this page';
  document.getElementById('sub').textContent   = '';
}

function samePage(a, b) {
  try {
    var urlA = new URL(a);
    var urlB = new URL(b);
    urlA.hash = '';
    urlB.hash = '';
    return urlA.href === urlB.href;
  } catch(e) {
    return a === b;
  }
}

function setApiEnvSelect(config) {
  var envSelect = document.getElementById('api-env');
  if (!envSelect || !config || !config.env) return;
  envSelect.value = config.env;
}

function setupApiEnvironmentControls() {
  var envSelect = document.getElementById('api-env');
  if (!envSelect || typeof envSelect.addEventListener !== 'function') return;

  chrome.runtime.sendMessage({ type: 'GET_API_CONFIG' }, function(config) {
    if (!chrome.runtime.lastError) setApiEnvSelect(config);
  });

  envSelect.addEventListener('change', function() {
    chrome.runtime.sendMessage({ type: 'SET_API_ENV', env: envSelect.value }, function(config) {
      if (!chrome.runtime.lastError) setApiEnvSelect(config);
    });
  });
}

// ── Run immediately when popup opens ─────────────────────────────────────────

setupApiEnvironmentControls();

chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
  if (!tabs || tabs.length === 0) {
    showError('No active tab found');
    return;
  }

  var url = tabs[0].url || '';
  document.getElementById('url-val').textContent = url || '—';

  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    showError('Not a web page');
    document.getElementById('sub').textContent = 'GuardAI only scans http/https pages';
    return;
  }

  var localResult = scan(url);
  showResult(url, localResult.score, localResult.flags);

  chrome.runtime.sendMessage({ type: 'GET_TAB_RISK' }, function(riskData) {
    if (chrome.runtime.lastError || !riskData || !samePage(riskData.url, url)) {
      return;
    }

    showResult(url, riskData.score || 0, riskData.flags || []);
  });
});
