/**
 * GuardAI – Content Script: formWatcher.js
 * NO IMPORTS — content scripts cannot use ES modules
 */

(function () {
  'use strict';

  if (window.__guardai_formwatcher_loaded) return;
  window.__guardai_formwatcher_loaded = true;

  var pendingSubmit = null;

  function showWarningBanner(score, onContinue) {
    var existing = document.getElementById('guardai-warning');
    if (existing) existing.remove();

    var banner = document.createElement('div');
    banner.id  = 'guardai-warning';

    var isHighRisk = score >= 0.85;
    var bgColor    = isHighRisk ? '#7F1D1D' : '#78350F';
    var message    = isHighRisk
      ? 'GuardAI: This site is flagged as highly dangerous. Do NOT enter your password or payment details unless you trust it.'
      : 'GuardAI: This site looks suspicious. Be careful before entering any personal information.';

    banner.style.cssText = [
      'position:fixed', 'top:0', 'left:0', 'width:100%',
      'background:' + bgColor, 'color:#FEF2F2',
      'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
      'font-size:14px', 'font-weight:500', 'padding:12px 20px',
      'z-index:2147483647', 'box-sizing:border-box',
      'display:flex', 'align-items:center', 'justify-content:space-between',
      'gap:16px', 'box-shadow:0 8px 24px rgba(0,0,0,0.3)'
    ].join(';');

    var text = document.createElement('span');
    text.textContent = message;
    text.style.cssText = 'flex:1;line-height:1.4';

    var actions = document.createElement('div');
    actions.style.cssText = 'display:flex;align-items:center;gap:8px;flex-shrink:0';

    var continueBtn = document.createElement('button');
    continueBtn.textContent = 'Continue anyway';
    continueBtn.style.cssText = [
      'background:#FEF2F2',
      'border:1px solid rgba(255,255,255,0.8)',
      'color:' + bgColor, 'cursor:pointer',
      'padding:6px 12px', 'border-radius:4px',
      'font-size:12px', 'font-weight:700'
    ].join(';');
    continueBtn.onclick = function() {
      var confirmed = window.confirm(
        'GuardAI warning: This site may be unsafe. Are you sure you want to continue and submit this form?'
      );
      if (!confirmed) return;
      banner.remove();
      onContinue();
      pendingSubmit = null;
    };

    var dismissBtn = document.createElement('button');
    dismissBtn.textContent = 'Dismiss';
    dismissBtn.style.cssText = [
      'background:rgba(255,255,255,0.15)',
      'border:1px solid rgba(255,255,255,0.3)',
      'color:#FEF2F2', 'cursor:pointer',
      'padding:6px 12px', 'border-radius:4px',
      'font-size:12px'
    ].join(';');
    dismissBtn.onclick = function() {
      banner.remove();
    };

    banner.appendChild(text);
    actions.appendChild(continueBtn);
    actions.appendChild(dismissBtn);
    banner.appendChild(actions);
    document.documentElement.prepend(banner);
  }

  function watchForms() {
    document.addEventListener('submit', function(event) {
      var form = event.target;
      if (!form.querySelector('input[type="password"]')) return;
      if (form.dataset.guardaiAllowSubmit === '1') {
        delete form.dataset.guardaiAllowSubmit;
        return;
      }

      event.preventDefault();
      event.stopImmediatePropagation();

      var submitter = event.submitter || null;
      pendingSubmit = { form: form, submitter: submitter };
      chrome.runtime.sendMessage({ type: 'GET_TAB_RISK' }, function(riskData) {
        if (!riskData) {
          pendingSubmit = null;
          continueSubmit(form, submitter);
          return;
        }
        var score = riskData.score || 0;
        if (score >= 0.5) {
          showWarningBanner(score, function() {
            if (pendingSubmit && pendingSubmit.form === form) {
              continueSubmit(form, submitter);
            }
          });
        } else {
          pendingSubmit = null;
          continueSubmit(form, submitter);
        }
      });
    }, true);
  }

  function continueSubmit(form, submitter) {
    form.dataset.guardaiAllowSubmit = '1';
    if (typeof form.requestSubmit === 'function') {
      try {
        form.requestSubmit(submitter || undefined);
        return;
      } catch (err) {
        form.requestSubmit();
        return;
      }
    }
    form.submit();
  }

  watchForms();

})();
