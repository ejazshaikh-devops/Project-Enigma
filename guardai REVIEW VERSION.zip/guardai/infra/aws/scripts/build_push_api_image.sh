#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib.sh"

load_env_file "${1:-}"
require_env AWS_REGION AWS_ACCOUNT_ID ECR_REPOSITORY

require_command aws
require_command docker
verify_aws_account

ROOT="$(repo_root)"
IMAGE_TAG_RESOLVED="$(image_tag_or_git_sha)"
IMAGE_URI="$(ecr_image_uri)"
REGISTRY="$(ecr_registry)"

echo "== Ensure ECR repository exists =="
aws ecr describe-repositories \
  --region "$AWS_REGION" \
  --repository-names "$ECR_REPOSITORY" >/dev/null 2>&1 || \
  aws ecr create-repository \
    --region "$AWS_REGION" \
    --repository-name "$ECR_REPOSITORY" >/dev/null

echo "== Login to ECR =="
aws ecr get-login-password --region "$AWS_REGION" | \
  docker login --username AWS --password-stdin "$REGISTRY"

echo "== Build image =="
docker build \
  -f "$ROOT/guardai/backend/Dockerfile" \
  -t "$IMAGE_URI:$IMAGE_TAG_RESOLVED" \
  -t "$IMAGE_URI:staging" \
  "$ROOT/guardai/backend"

echo "== Push image =="
docker push "$IMAGE_URI:$IMAGE_TAG_RESOLVED"
docker push "$IMAGE_URI:staging"

echo "Pushed:"
echo "  $IMAGE_URI:$IMAGE_TAG_RESOLVED"
echo "  $IMAGE_URI:staging"
