#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck disable=SC1091
source "$SCRIPT_DIR/lib.sh"

load_env_file "${1:-}"
require_env \
  AWS_REGION \
  AWS_ACCOUNT_ID \
  ECR_REPOSITORY \
  API_HOSTNAME \
  ACM_CERTIFICATE_ARN \
  CHROME_EXTENSION_ID

require_command kubectl

ROOT="$(repo_root)"
WORK_DIR="$(mktemp -d)"
trap 'rm -rf "$WORK_DIR"' EXIT

cp -R "$ROOT/guardai/infra/k8s" "$WORK_DIR/k8s"

IMAGE_TAG_RESOLVED="$(image_tag_or_git_sha)"
IMAGE_URI="$(ecr_image_uri)"
OVERLAY="$WORK_DIR/k8s/overlays/staging"

sed -i.bak "s|REPLACE_WITH_AWS_ACCOUNT_ID.dkr.ecr.REPLACE_WITH_REGION.amazonaws.com/guardai-api|$IMAGE_URI|g" "$OVERLAY/kustomization.yaml"
sed -i.bak "s|newTag: \"staging\"|newTag: \"$IMAGE_TAG_RESOLVED\"|g" "$OVERLAY/kustomization.yaml"
sed -i.bak "s|chrome-extension://REPLACE_WITH_EXTENSION_ID|chrome-extension://$CHROME_EXTENSION_ID|g" "$OVERLAY/configmap.patch.yaml"
sed -i.bak "s|api-staging.guardai.io|$API_HOSTNAME|g" "$OVERLAY/ingress.patch.yaml"
sed -i.bak "s|REPLACE_WITH_ACM_CERTIFICATE_ARN|$ACM_CERTIFICATE_ARN|g" "$OVERLAY/ingress.patch.yaml"

find "$WORK_DIR" -name '*.bak' -delete
kubectl kustomize "$OVERLAY"
