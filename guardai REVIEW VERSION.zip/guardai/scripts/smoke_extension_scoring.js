const fs = require("fs");
const path = require("path");
const vm = require("vm");

const root = path.resolve(__dirname, "..");
const popupPath = path.join(root, "extension", "popup", "popup.js");
const popupCode = fs.readFileSync(popupPath, "utf8");

const noopElement = {
  classList: { add() {}, remove() {} },
  style: {},
  textContent: "",
  innerHTML: "",
  appendChild() {},
};

const context = {
  console,
  URL,
  chrome: {
    runtime: {},
    tabs: {
      query() {},
    },
  },
  document: {
    getElementById() {
      return noopElement;
    },
    createElement() {
      return { textContent: "" };
    },
  },
};

vm.createContext(context);
vm.runInContext(popupCode, context, { filename: popupPath });

const cases = [
  {
    name: "normal_https",
    url: "https://www.google.com",
    min: 0.03,
    max: 0.10,
  },
  {
    name: "normal_login",
    url: "https://accounts.google.com/login",
    min: 0.08,
    max: 0.20,
  },
  {
    name: "http_login",
    url: "http://example.com/login",
    min: 0.20,
    max: 0.35,
  },
  {
    name: "known_phishing",
    url: "http://paypa1.com/login",
    min: 0.85,
    max: 1.0,
  },
  {
    name: "phishing_style_paypal",
    url: "https://paypal-login-secure.xyz/verify?redirect=%2Faccount",
    min: 0.85,
    max: 1.0,
  },
];

let failures = 0;

for (const testCase of cases) {
  const result = context.scan(testCase.url);
  const ok = result.score >= testCase.min && result.score <= testCase.max;
  const score = Math.round(result.score * 100);
  const flags = result.flags.length ? result.flags.join(",") : "none";

  console.log(`${ok ? "PASS" : "FAIL"} ${testCase.name}: ${score}/100 [${flags}]`);

  if (!ok) {
    failures += 1;
    console.error(
      `  Expected ${testCase.min * 100}-${testCase.max * 100}/100, got ${score}/100`
    );
  }
}

if (failures > 0) {
  process.exit(1);
}

